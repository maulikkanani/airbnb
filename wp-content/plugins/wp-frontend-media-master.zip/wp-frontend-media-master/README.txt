=== Front-end Media Example ===
Contributors: derekspringer
Donate link: http://example.com/
Tags: media
Requires at least: 3.8
Tested up to: 4.2
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An example of adding the media loader on the front-end.

== Description ==

TODO

== Installation ==

TODO

== Changelog ==

= 0.1 =
First version.
